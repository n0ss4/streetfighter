<template>
  <div class="about">
    <img src="./../assets/logo.png"/>
    <p><span class="text-uppercase">Aplicación creada por</span> n0ss4.</p>
  </div>
</template>