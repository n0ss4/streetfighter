<template>
  <div class="about">
    <img src="./../assets/logo.png"/>
    <p style="font-family: Consolas;"><span class="text-uppercase">Aplicación creada por </span> <a href="https://github.com/n0ss4">n0ss4</a>.</p>
  </div>
</template>